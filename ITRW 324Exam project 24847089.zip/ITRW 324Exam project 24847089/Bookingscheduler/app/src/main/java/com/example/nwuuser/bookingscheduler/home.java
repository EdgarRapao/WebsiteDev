package com.example.nwuuser.bookingscheduler;

import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.net.Uri;

import static com.example.nwuuser.bookingscheduler.R.*;


public class home extends AppCompatActivity {
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_home);

        mDrawerLayout =(DrawerLayout) findViewById(id.drawerLayout);
        mToggle = new ActionBarDrawerToggle(this,mDrawerLayout, string.open, string.close);

        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();

       // getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

   @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       if(mToggle.onOptionsItemSelected(item)){
          return true;
        }
        return super.onOptionsItemSelected(item);
   }
    public  void Blog(MenuItem item)
    {
        Uri uri = Uri.parse("http://rkv-lnx3.puk.ac.za/~v24847089/Group%2012%20Website/Blog.html");

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
    public  void Camera(MenuItem item)
    {
        Intent intent = new Intent(this,CameraImage.class);
        startActivity(intent);
    }
    public  void logout(MenuItem item)
    {
       Intent intent = new Intent(this,MainActivity.class);
       startActivity(intent);
        finish();
    }
    public  void  Venues(MenuItem item)
    {
        Intent intent = new Intent(this, Venues.class);
        startActivity(intent);

    }

    public  void  settings(MenuItem item)
    {
        Uri uri = Uri.parse("http://www.nwu.ac.za/content/account-enquiries");

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);



    }
    public  void   home(MenuItem item)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

    public  void   admin(MenuItem item)
    {
        Intent intent = new Intent(this, MyDatabaseHelper.class);
        startActivity(intent);

    }
    public  void     About(MenuItem item)
    {
        Uri uri = Uri.parse("http://rkv-lnx3.puk.ac.za/~v24847089/Group%2012%20Website/About.html");

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);


    }





}


