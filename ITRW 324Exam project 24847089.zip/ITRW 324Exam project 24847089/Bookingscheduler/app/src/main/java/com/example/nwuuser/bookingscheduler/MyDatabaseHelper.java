package com.example.nwuuser.bookingscheduler;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MyDatabaseHelper extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText editVenues, editDay, editModules, editTime,editId;

    Button btnAddData;
    Button btnviewAll;
    Button btnDelete;

    Button btnviewUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_database_helper);
        myDb = new DatabaseHelper(this);

        editVenues = (EditText) findViewById(R.id.editText_name);
        editDay = (EditText) findViewById(R.id.editText_surname);
        editModules = (EditText) findViewById(R.id.editText_Marks);
        editTime = (EditText) findViewById(R.id.editText_time);
        editId = (EditText) findViewById(R.id.editText_id);
      //casting
        btnAddData = (Button) findViewById(R.id.button_add);
        btnviewAll = (Button) findViewById(R.id.button_viewAll);
        btnviewUpdate = (Button) findViewById(R.id.button_update);
        btnDelete = (Button) findViewById(R.id.button_delete);
        viewAll();
        AddData();
        updateData();
        DeleteData();
    }
    //create functions

    public void DeleteData() {
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDb.deleteData(editId.getText().toString());
                        if(deletedRows > 0)
                            Toast.makeText(MyDatabaseHelper.this,"Data Deleted",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MyDatabaseHelper.this,"Data not Deleted",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }


    public void updateData() {
        btnviewUpdate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdate = myDb.updateData(editId.getText().toString(),editVenues.getText().toString(),
                                editModules.getText().toString(),editTime.getText().toString(),editDay.getText().toString());

                        if(isUpdate == true)
                            Toast.makeText(MyDatabaseHelper.this,"Data Update",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MyDatabaseHelper.this,"Data not Updated",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
    public void AddData() {
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(editVenues.getText().toString(),
                                editDay.getText().toString(), editModules.getText().toString(),
                                editTime.getText().toString());

                        if (isInserted == true)
                            Toast.makeText(MyDatabaseHelper.this, "Data Inserted to Database", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MyDatabaseHelper.this, "Data Not Inserted to Database", Toast.LENGTH_LONG).show();
                    }
                }
        );

    }
    public void viewAll(){
        btnviewAll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                        if (res.getCount() == 0) {
                            // show message
                            showMessage("Error", "Nothing found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("ID :" + res.getString(0) + "\n");
                            buffer.append("VENUES :" + res.getString(1) + "\n");
                            buffer.append("DAY :" + res.getString(2) + "\n");
                            buffer.append("MODULE :" + res.getString(2) + "\n");
                            buffer.append("TIME :" + res.getString(3) + "\n\n");
                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }
        public void showMessage(String title,String Message){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(title);
            builder.setMessage(Message);
            builder.show();
        }

}





