package com.example.nwuuser.bookingscheduler;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class RegisterUser extends AppCompatActivity {
  EditText name,surname,age,username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        name=(EditText)findViewById(R.id.nametxt);
        surname=(EditText)findViewById(R.id.surnametxt);
        age=(EditText)findViewById(R.id.agetxt);
        username=(EditText)findViewById(R.id.usernametxt);
        password=(EditText)findViewById(R.id.passwordtxt);
    }
    public void OnRegister(View view){


        String strname = name.getText().toString();
        String strsurname = surname.getText().toString();
        String strage = age.getText().toString();
        String strusername = username.getText().toString();
        String strpassword = password.getText().toString();

        String type ="Register";
        BagroundWorker bagroundWorker =new BagroundWorker(this);
        bagroundWorker.execute(strname,strsurname,strage,strusername,strpassword);


    }
    public void openRegister(View view){
        startActivity(new Intent(this,RegisterUser.class));
    }
}
