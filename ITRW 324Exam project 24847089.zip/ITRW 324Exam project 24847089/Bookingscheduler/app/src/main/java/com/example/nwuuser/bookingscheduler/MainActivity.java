package com.example.nwuuser.bookingscheduler;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    ImageButton myImageButton;
    CheckBox chechbox1;
    EditText UsernameEt, PasswordEt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UsernameEt = (EditText) findViewById(R.id.UsernameEt);
        PasswordEt = (EditText) findViewById(R.id.passwordEt);
    }

    public void OnLogin(View view) {
        String username = UsernameEt.getText().toString();
        String password = PasswordEt.getText().toString();
        String type ="login";
         BagroundWorker bagroundWorker =new BagroundWorker(this);
        bagroundWorker.execute(type,username,password);

    }
    public void openRegister(View view)
    {
        startActivity((new Intent(this,RegisterUser.class)));
    }
}

       // myImageButton = (ImageButton) findViewById(R.id.imageButton2);
       // chechbox1 = (CheckBox) findViewById(R.id.checkBoxLecture);

       // myImageButton.setOnClickListener(new View.OnClickListener() {
           // @Override
         // public void onClick(View v) {
             //   boolean checked = ((CheckBox) v).isChecked();

              //  switch (v.getId()) {
                  //  case R.id.checkBoxLecture:
                    //    if (checked) {
                           // Intent intent = new Intent(MainActivity.this,home.class);
                           // startActivity(intent);
                       // }

                //}
           // }


       // });
  //  }
//}

    //}

    //public void onCheckboxClicked(View view) {
        // Is the view now checked?
      //  boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
      //  switch(view.getId()) {
          //  case R.id.checkBoxLecture:
          //      if (checked) {
           //   /      Intent i1 = new Intent(MainActivity.this, MyDatabaseHelper.class);
                //    startActivity(i1);
           //     }
              //  else
                // Remove the meat
             //   break;
           // case R.id.checkBoxStudent:
          //      if (checked) {
                    // Cheese me
          //      }
             //   else
          //      // I'm lactose intolerant
           //     break;
        // TODO: Veggie sandwich
      //  }

          //  }
   // }

       // }



